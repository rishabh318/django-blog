=====
Blogs
=====

Blogs is a simple Django app to conduct Web-based Blogs. This Blog app
allows authorized users to maintain a blog. Blogs are a series of posts
that are time stamped and are typically viewed by date. Blog entries can
be made depending on which roles have access to add blog.

Quick start
-----------

1. Add "polls" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'blog',
    ]

2. Include the polls URLconf in your project urls.py like this::

    url(r'^blog/', include('blog.urls')),

3. Run `python manage.py migrate` to create the polls models.

4. Start the development server and visit http://127.0.0.1:8000/admin/
   to create a poll (you'll need the Admin app enabled).

5. Visit http://127.0.0.1:8000/blog/ to participate in the poll.
